
KuiSpellListConfigSaved = {
	["include_own"] = {
		[204242] = true,
		[6343] = true,
		[240842] = true,
		[257284] = true,
		[31589] = true,
		[205708] = true,
		[116095] = true,
		[2120] = true,
		[212792] = true,
		[1715] = true,
		[121253] = true,
		[236027] = true,
		[213405] = true,
		[3409] = true,
		[183218] = true,
		[45524] = true,
		[5116] = true,
		[196840] = true,
		[271788] = true,
		[12323] = true,
	},
	["include_all"] = {
	},
	["exclude"] = {
	},
}
