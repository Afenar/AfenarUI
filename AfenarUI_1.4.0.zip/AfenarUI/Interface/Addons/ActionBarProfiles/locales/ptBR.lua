local addonName = ...

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "ptBR", false)
if not L then return end

L["charframe_tab"] = "Barra de Ações"
L["confirm_delete"] = "Você tem certeza que deseja apagar o perfil %s?"
L["confirm_overwrite"] = "O perfil %s já existe, gostaria de sobrescreve-lo?"
L["confirm_save"] = "Você gostaria de salvar o perfil %s?"
L["confirm_use"] = "%s de %s ações deste perfil não podem ser usadas por este personagem. Usar este perfil mesmo assim?"
L["error_exists"] = "Um perfil com aquele nome já existe."
L["minimap_icon"] = "Ícone do mini mapa"
L["new_profile"] = "Novo Perfil"
-- L["no_profiles"] = ""
L["option_companions"] = "Montarias e Mascotes"
L["option_empty_slots"] = "Slots Vazios"
L["option_equip_sets"] = "Conjuntos de Equipamentos"
L["option_items"] = "Itens"
L["option_key_bindings"] = "Teclas de Atalhos"
L["option_macros"] = "Macros"
L["option_pet_spells"] = "Ações de Ajudantes"
-- L["option_spells"] = ""
-- L["option_talents"] = ""
L["profile_name"] = "Digite o Nome do Novo Perfil (Max 16 Letras):"
L["profile_options"] = "Salvar no Perfil:"
-- L["settings"] = ""
L["tooltip_profiles"] = "Perfis Disponíveis"

