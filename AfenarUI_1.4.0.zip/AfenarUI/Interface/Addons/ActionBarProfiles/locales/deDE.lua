local addonName = ...

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "deDE", false)
if not L then return end

L["charframe_tab"] = "Aktionsleisten"
L["confirm_delete"] = "Bist Du sicher, dass Du das Profil \"%s\" löschen möchtet?"
L["confirm_overwrite"] = "Du hast bereits ein Profil namens \"%s\". Möchtest Du es überschreiben?"
L["confirm_save"] = "Möchtest Du das Profil \"%s\" speichern?"
L["confirm_use"] = "%s der %s Aktionen dieses Profils kann nicht vom aktuellen Charakter verwendet wird. Möchtest Du dieses Profil trotzdem verwenden?"
L["error_exists"] = "Ein Profil mit diesem Namen gibt es bereits."
L["minimap_icon"] = "Minikartensymbol"
L["new_profile"] = "Neues Profil"
L["no_profiles"] = "Keine verfügbaren Profile"
L["option_companions"] = "Reittiere und Begleiter"
L["option_empty_slots"] = "Leere Plätze"
L["option_equip_sets"] = "Ausrüstungssets"
L["option_items"] = "Gegenstände"
L["option_key_bindings"] = "Tastenbelegungen"
L["option_macros"] = "Makros"
L["option_pet_spells"] = "Begleiter- oder Dämonenaktionen"
-- L["option_spells"] = ""
L["option_talents"] = "Talente"
L["profile_name"] = "Gib einen Profilnamen ein (max. 16 Zeichen):"
L["profile_options"] = "Speichern in Profil:"
L["settings"] = "Einstellungen"
L["tooltip_profiles"] = "Verfügbare Profile:"

