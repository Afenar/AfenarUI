local addonName = ...

local L = LibStub("AceLocale-3.0"):NewLocale(addonName, "frFR", false)
if not L then return end

-- L["charframe_tab"] = ""
-- L["confirm_delete"] = ""
-- L["confirm_overwrite"] = ""
-- L["confirm_save"] = ""
-- L["confirm_use"] = ""
-- L["error_exists"] = ""
-- L["minimap_icon"] = ""
-- L["new_profile"] = ""
-- L["no_profiles"] = ""
-- L["option_companions"] = ""
-- L["option_empty_slots"] = ""
-- L["option_equip_sets"] = ""
-- L["option_items"] = ""
-- L["option_key_bindings"] = ""
-- L["option_macros"] = ""
-- L["option_pet_spells"] = ""
-- L["option_spells"] = ""
-- L["option_talents"] = ""
-- L["profile_name"] = ""
-- L["profile_options"] = ""
-- L["settings"] = ""
-- L["tooltip_profiles"] = ""

