--[[
AdiBags_Bound - Adds BoE/BoA filters to AdiBags.
Copyright 2010-2012 Kevin (kevin@outroot.com)
All rights reserved.
--]]

local _, ns = ...

local addon = LibStub('AceAddon-3.0'):GetAddon('AdiBags')
local L = setmetatable({}, {__index = addon.L})

do -- Localization
	L['Duplicate item count'] = 'Duplicate item count'
	L['Display the amount of copies of an item you have in other bags.'] = 'Display the amount of copies of an item you have in other bags.'
	L['Only equippable items'] = 'Only equippable items'
	L['Do not show duplicates of items that cannot be equipped.'] = 'Do not show duplicates of items that cannot be equipped.'
	L['Ignore low quality items'] = 'Ignore low quality items'
	L['Do not show duplicates of poor quality items.'] = 'Do not show duplicates of poor quality items.'
	L['Ignore heirloom items'] = 'Ignore heirloom items'
	L['Do not show duplicates of heirloom items.'] = 'Do not show duplicates of heirloom items.'
	L['Mininum level'] = 'Mininum level'
	L['Do not show levels under this threshold.'] = 'Do not show levels under this threshold.'
	
  local locale = GetLocale()
  if locale == "frFR" then

  elseif locale == "deDE" then
	
  elseif locale == "esMX" then
	
  elseif locale == "ruRU" then
	
  elseif locale == "esES" then
	
  elseif locale == "zhTW" then
	
  elseif locale == "zhCN" then
	
  elseif locale == "koKR" then
	
  end
end

local mod = addon:NewModule('DuplicateItem', 'AceEvent-3.0')
mod.uiName = L['Duplicate item count']
mod.uiDesc = L['Display the amount of copies of an item you have in other bags.']

local texts = {}
local ItemUpgradeInfo = LibStub('LibItemUpgradeInfo-1.0')

--mod:OnInitialize
function mod:OnInitialize()
	self.db = addon.db:RegisterNamespace(self.moduleName, {
		profile = {
			minLevel = 1,
			equippableOnly = false,
			ignoreJunk = true,
			ignoreHeirloom = true
		},
	})
	

end

--mod:OnEnable
function mod:OnEnable()
	self:RegisterMessage('AdiBags_BagOpened', 'UpdateCounts')
	self:RegisterMessage('AdiBags_UpdateButton', 'UpdateButton')
	self:SendMessage('AdiBags_UpdateAllButtons')
end

--mod:OnDisable
function mod:OnDisable()
	for _, text in pairs(texts) do
		text:Hide()
	end
end

local function CreateText(button)
	local text = button:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
	text:SetPoint("BOTTOMLEFT", button, 3, -1)
	text:Hide()
	texts[button] = text
	return text
end

local voidItems = {}
function mod:UpdateCounts(event, bagname)
	voidItems = {}
	local character = DataStore:GetCharacter()
	local voidStorage = DataStore:GetContainer(character, "VoidStorage")
	local voidSize = voidStorage['size']
	for _, voidId in pairs(voidStorage.ids) do
		local voidName, _, _, _, _, _, _, _, _ = GetItemInfo(voidId)
		
		if voidName then
			local voidItem = voidItems[voidName]
			if voidItem then
				voidItems[voidName] = voidItem + 1
			else
				voidItems[voidName] = 1
			end
		end
	end
end

--mod:UpdateButton(event, button) --where we set the text on a button if it's an item
function mod:UpdateButton(event, button)
	local settings = self.db.profile
	local link = button:GetItemLink()
	local text = texts[button]
	
	if link then
		local itemName, _, quality, _, reqLevel, _, _, _, loc = GetItemInfo(link)
		local level = ItemUpgradeInfo:GetUpgradedItemLevel(link) or 0
		local duplicateCount = 1
		
		local voidItem = voidItems[itemName]
		
		if duplicateCount > 0
			and voidItem
			and level >= settings.minLevel			
			and (not settings.ignoreJunk or quality > 0)
			and (not settings.equippableOnly or loc ~= "")
			and (not settings.ignoreHeirloom or quality ~= 7)
		then
			if not text then
				text = CreateText(button)
			end
			text:SetText(voidItem)
			text:SetTextColor(1.00, 1.00, 1.00)
			return text:Show()
		end
	end
end

--mod:GetOptions
--options:
	--minLevel
	--ignoreJunk
	--ignoreHeirloom
	--corner
function mod:GetOptions()
	return {
		minLevel = {
			name = L['Mininum level'],
			desc = L['Do not show levels under this threshold.'],
			type = 'range',
			min = 1,
			max = 600,
			step = 1,
			bigStep = 5,
			order = 30
		},
		equippableOnly = {
			name = L['Only equippable items'],
			desc = L['Do not show duplicates of items that cannot be equipped.'],
			type = 'toggle',
			order = 10,
		},
		ignoreJunk = {
			name = L['Ignore low quality items'],
			desc = L['Do not show duplicates of poor quality items.'],
			type = 'toggle',
			order = 40,
		},
		ignoreHeirloom = {
			name = L['Ignore heirloom items'],
			desc = L['Do not show duplicates of heirloom items.'],
			type = 'toggle',
			order = 50,
		}
	}, addon:GetOptionHandler(self)
end
